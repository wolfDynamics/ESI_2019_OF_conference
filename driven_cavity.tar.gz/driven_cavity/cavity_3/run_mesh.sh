#!/bin/bash


foamCleanTutorials


cd refinementZone
rm -rf 0 > /dev/null 2>&1
blockMesh | tee log.blockMesh
transformPoints -translate '(0.015 0.015 0)'

cd ..

cd all
rm -rf 0 > /dev/null 2>&1
blockMesh | tee log.blockMesh

topoSet
#subsetMesh -overwrite c0 -patch hole
subsetMesh -overwrite c0 -patch oversetPatch

mergeMeshes . ../refinementZone -overwrite | tee log.mergeMeshes

#To create regions also
checkMesh |  tee log.checkMesh

rm -rf 0 > /dev/null 2>&1
cp -r 0_org 0 > /dev/null 2>&1

#To initialize regions
setFields | tee log.setFields

cd ..

