 #!/bin/bash

cd all

#overPimpleDyMFoam | tee log.solver

decomposePar
mpirun -np 4 renumberMesh -overwrite -parallel | tee log.renumberMesh
mpirun -np 4 overPimpleDyMFoam -parallel | tee log.solver

