#!/bin/bash


foamCleanTutorials


cd refinementZone
blockMesh | tee log.blockMesh
#transformPoints -rollPitchYaw '(0 0 30)'
transformPoints -rotate-angle '((0 0 1) 30)'
transformPoints -translate '(0.35 -0.1 0)'

cd ..

cd all
blockMesh | tee log.blockMesh

mergeMeshes . ../refinementZone -overwrite | tee log.mergeMeshes

#createPatch -overwrite | tee log.createPatch
#changeDictionary | tee log.changeDictionary
#topoSet | tee log.topoSet

checkMesh |  tee log.checkMesh

rm -r 0
cp -r 0_org 0

setFields | tee log.setFields

0.35 -0.1
