#!/bin/bash


foamCleanTutorials

cd cylinder
blockMesh | tee log.blockMesh
cd ..

cd refinementZone
blockMesh | tee log.blockMesh
cd ..

cd all

rm -r 0

blockMesh | tee log.blockMesh
topoSet
subsetMesh -overwrite c0 -patch oversetPatch

mergeMeshes . ../cylinder -overwrite | tee log.mergeMeshes1
mergeMeshes . ../refinementZone -overwrite | tee log.mergeMeshes2

#createPatch -overwrite | tee log.createPatch
#changeDictionary | tee log.changeDictionary
#topoSet | tee log.topoSet

checkMesh |  tee log.checkMesh

rm -r 0
cp -r 0_org 0

setFields | tee log.setFields


