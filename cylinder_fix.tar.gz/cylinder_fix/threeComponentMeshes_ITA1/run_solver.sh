 #!/bin/bash

cd all

setFields -dict system/setFieldsDict_init  | tee log.setFieldsDict_init 

decomposePar

mpirun -np 4 renumberMesh -overwrite -parallel | tee log.renumberMesh

mpirun -np 4 overPimpleDyMFoam -parallel | tee log.solver

