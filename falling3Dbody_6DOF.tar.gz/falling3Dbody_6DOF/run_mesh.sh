#!/bin/bash


foamCleanTutorials

cd floatingbody/

blockMesh
topoSet
subsetMesh -overwrite c0 -patch floatingObject

cd ..



cd background/

blockMesh
mergeMeshes . ../floatingbody -overwrite | tee log.mergeMeshes

topoSet | tee log.topoSet

rm -rf 0
cp -r 0_org 0


setFields -dict system/setFieldsDict_zoneID | tee log.setFields_zoneID

setFields -dict system/setFieldsDict_alpha.water | tee log.setFields_alpha.water


checkMesh |  tee log.checkMesh

cd ..
