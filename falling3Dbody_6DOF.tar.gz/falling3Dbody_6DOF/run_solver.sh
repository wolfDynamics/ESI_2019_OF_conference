 #!/bin/bash

cd background/

#decomposePar

#mpirun -np 4 renumberMesh -overwrite -parallel | tee log.renumberMesh

#mpirun -np 4 overInterDyMFoam -parallel | tee log.solver


renumberMesh -overwrite | tee log.renumberMesh
overInterDyMFoam | tee log.solver

